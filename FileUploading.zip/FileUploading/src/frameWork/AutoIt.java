package frameWork;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class AutoIt {

	public static void main(String[] args) throws IOException {

		System.setProperty("webdriver.chrome.driver", "C:\\Windows\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://demoqa.com/automation-practice-form");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		try {
			driver.findElement(By.xpath("//input[@id='firstName']")).sendKeys("Stephen");
			driver.findElement(By.xpath("//input[@id='lastName']")).sendKeys("Raj");
			driver.findElement(By.xpath("//input[@id='userEmail']")).sendKeys("Raj@gamil.com");
			driver.findElement(By.xpath("//label[text()='Male']")).click();
			driver.findElement(By.xpath("//input[@id='userNumber']")).sendKeys("9876543212");
			driver.findElement(By.xpath("//input[@id='dateOfBirthInput']")).click();
			driver.findElement(By.xpath("//div[text()='17']")).click();

			JavascriptExecutor javas = (JavascriptExecutor) driver;
			javas.executeScript("window.scrollTo(1 , document.body.scrollHeight)");

			driver.findElement(By.xpath("//label[text()='Music']")).click();
			Actions Do = new Actions(driver);
			WebElement upload = driver.findElement(By.xpath("//input[@id='uploadPicture']"));
			Do.moveToElement(upload).click().perform();

			Runtime.getRuntime().exec("F:\\FileUploadScript.exe");
			Thread.sleep(8000);

			driver.findElement(By.xpath("//textarea[@id='currentAddress']")).sendKeys("New Address");
			driver.findElement(By.id("submit")).click();

			driver.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
